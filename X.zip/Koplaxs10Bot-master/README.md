# KoplaxsBotProtect
Koplaxs BOT Protect
Versi TCR
====================================================
Bot Protect TCR Versi  1 admin dan 10 Bot + 1 Backup
====================================================
Bot Line Versi Protect Group
-Siapkan 1 Akun Utama Dan 10 Akun Bot  + 1 Akun Untuk Backup
Apa Gunanya Bot Backup? 
Untuk Membackup Akun Utama Jika Ga ada di room
BOT Backup ini Adanya Di Luar Group :D
Jadi Di Gunakan Jika Kalo Situasi Darurat :v


Fungsinya?
Kelebihan :
1.Protect Group Line Pastinya
2.Dapat Menambah Owner,Admin/Staff Kedalam Bot
3.Command Bisa Dipakai oleh Orang Admin
4.Bot Tidak Saling Kick Ketika Ada Yang Terkick
5.Jika Ingin Protect Lebih Dari 1 Group, Kalian Tidak Wajib ada di Semua Group Tersebut

Kelemahan:
1.BOT Tidak Aktif Ketika Bot Induk Tidak ada di Dalam Group


Cara Instal :
- pkg install python -y
- pkg install python2 -y
- pkg install git -y
- git clone https://github.com/koplaxs/Koplaxs10Bot
- pip2 install rsa
- pip2 install thrift==0.9.3
- pip2 install requests

Cara Menjalankan Botnya :
- cd KoplaxsBotProtect
- python KoplaxsProtect.py


Video Tutor :
https://youtu.be/Jq_nyqFe7o4

Cara edit File lewat Nano(no root)
https://youtu.be/q7zYkOv_ZAA

Ada Pertanyaan?
Add My Line => @hanavy1992

Thanks For :
- Alfathdirk
- Farzain
- Dan Kawan²
=======================
Koplaxs & One Piece Bot
=======================
